<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="js/jquery-1.12.1.js"></script>
<script src="js/lity.js"></script>
<link rel="stylesheet" type="text/css" href="js/lity.css">
	<title></title>
</head>
<body>
 <form class="form-horizontal" role="form" method="POST" accept-charset="utf-8" action="rncfguardar.php">
               <div class="form-group">
                 <label class="col-md-4 control-label">Fecha:
            </label>
                <div class="col-md-6">
                           <label class="col-md-4 control-label" for="fecha" name="fecha" id="fecha"> <input type="text" name="fecha"> <script>
var f = new Date();
var B =(f.getFullYear() + "/" + (f.getMonth() +1) + "/" + f.getDate());
document.write(f.getFullYear() + "/" + (f.getMonth() +1) + "/" + f.getDate());
</script></label> 

   
                            </div>
                            </div>
                
          				<div class="form-group">
      <label class="col-md-4 control-label" for="sel1">generar No. no conformidad:</label>
      <div class="col-md-6">
      <select class="form-control" id="sel1" name="sel1">
        <option>AUI</option>
        <option>AUT</option>
        <option>AUP</option>
        <option>SGC</option>
        <option>QCL</option>

      </select>
      </div>
      </div>
                     
                        <div class="form-group">
                        <label class="col-md-4 control-label">Elabora No Conformidad
            </label>
							
							 <div class="col-md-6">
                            <label class="col-md-4 control-label" for="elanocon" >aaron<input type="" name="elanocon" id="elanocon">
            </label>
              </div>
                            </div>
                            <div class="form-group">
                        <label class="col-md-4 control-label">No referencia</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="referencia" id="referencia" >
                            </div>
                            </div>
                             <div class="form-group">
                        <label class="col-md-4 control-label">dep./area identificado</label>
							
							 <div class="col-md-6">
                                <input type="text" class="form-control" name="deparin" id="deparin" >
                            </div>
                            </div>
		 <div class="form-group">
                        <label class="col-md-4 control-label">Responsable de la n.c.</label>
							
							 <div class="col-md-6">
                                <input type="text" class="form-control" name="resnc" id="resnc">
                            </div>
		</div>
		<div class="form-group">
                        <label class="col-md-4 control-label">descripcion de hallazgo</label>
							
							 <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="descdha" name="descdha"></textarea>
                            </div>
                          	 
      
  
		</div>    	
                      

                        
						<div class="modal-footer">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" data-dismiss="modal" id="acceso" name="acceso">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>

                                
                            </div>
                        </div>
                        </div>
            
                    </form>

                    <a href="//www.youtube.com/embed/eRW84aVCMWo" data-lity="Youtube">
Launch Youtube overlay
</a>
<a class="example-image-link" href="doc.html" data-lity="example-2" data-title="Optional caption."><img class="example-image" src="aav.jpg" alt="image-1"></a>


<a href="http://maps.google.com/maps?q=1600+Amphitheatre+Parkway,+Mountain+View,+CA" data-lity="">http://maps.google.com/maps?q=1600+Amphitheatre+Parkway,+Mountain+View,+CA</a>
<a href="jefe.php" data-toggle="modal" data-target="#departamento" data-lity="">hacer reporte</a>
                    <script type="text/javascript">
                  

                    </script>
</body>
</html>