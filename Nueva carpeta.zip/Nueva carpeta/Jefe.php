<!DOCTYPE html>
<html>
<?php 
/*include_once("seguridad.php");*/
session_start(); ?>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
   
  <link rel="stylesheet" type="text/css" href="vista.css">

<script type="text/javascript" src="js/jquery-1.12.1.js"></script>

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<script type="text/javascript" src="js/bootstrap.js"></script>
	<title>valle</title>
</head>
<header>
	<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Agecua Aduanal del Valle</a>
    </div>
    <div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">
          <li><a href="#rncc">"Causas raiz de la no conformidad"</a></li>
          <li><a href="#rncc2">"Generar actividades"</a></li>
          <li><a href="#rncc3">"terminar"</a></li>
         
        </ul>
      </div>
    </div>
  </div>
</nav>
</header>
<body>


  <div class="modal-dialog-lg">
  <div class="modal-content">
                      <div class="modal-header">
         
          <h1 style="padding-top:50px;" class="text-center">"Acción Correctiva y/o Preventiva"</h1>
      </div> 
       <!--<button type="button" class="btn btn-warning btn-addBody">Añadir DIV al BODY</button>-->

<article>
  <form  method="post" class="form-horizontal" role="form">
         <div class="form-group">
                        <label class="col-md-4 control-label" id="rncc">causas raiz de la no confirmidad</label>
              
                <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="comment" name="descdha"></textarea>
                            </div>
                             
                            </div>
<div class="form-group" id="rncc2">        
            <label class="col-md-4 control-label" for="titulo" >Nombre de actividad:</label>
            <div class="col-md-4"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
 <div class="form-group">
                        <label for="descripcion" class="col-md-4 control-label">Descripcíon de la acción</label>
              
               <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="descripcion" name="descdha"></textarea>
                            </div>
                  </div>  

        
        <div class="form-group">
            <label class="col-md-4 control-label" for="Personal">Personal Responsable:</label>
             <div class="col-md-6">
            <select class="form-control"  id="Personal">
                <option value="1">Tipo 1</option>
                <option value="2">Tipo 2</option>
                <option value="3">Tipo 3</option>
            </select>
            </div>
        </div>
        <div class="form-group">
                        <label for="descripcion" class="col-md-4 control-label">ingresar archivo</label>
              
               <div class="col-md-6">
                               <input type="file" class="form-control"  id="archivo" name="ingar" >
                            </div>
                  </div>  

                     <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary" data-dismiss="modal" id="agregar">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>
                                
                               
        <div class="table-responsive">
         <table  class="table table-hover">
    <thead>
      <tr>
       <th>Actividad</th>
                <th>Descripcion</th>
                <th>Responsable</th>
                <th>Archivo adjunto</th>
                <th>editar</th>
      </tr>
    </thead>
    <tbody id="tabla-elementos">
     
    </tbody>
  </table>      
  </div>      
   
                            </div>


                        </div>

                 <div class="form-group">        
            <label class="col-md-4 control-label" for="titulo" id="rncc3">nombre y firma del responsable de la aplicacion:</label>
            <div class="col-md-6"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
        <div class="form-group">        
            <label class="col-md-4 control-label" for="titulo">Vo.Bo. de la accion gerende y jefe de C y RH:</label>
            <div class="col-md-6"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
        <div class="modal-footer">


            <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" data-dismiss="modal">
                                    <i class="fa fa-btn fa-sign-in"></i>terminar
                                </button>

                                
                            </div>
                        </div>
                     


                        
                        </div>
                


    </form>
    
   
</article>
</div>
</div>


 <script type="text/javascript">


  var tablaElementos = document.getElementById('tabla-elementos');

var txtTitulo = document.getElementById('titulo');
var txtDescripcion = document.getElementById('descripcion');
var ddlTipo = document.getElementById('Personal');
var archivoo = document.getElementById('archivo');




var btnAgregar = document.getElementById('agregar');

var datos = [];
var datos2 =[];

function btnEditar_Click(event) {

    txtTitulo.value = this.elemento.titulo;
    txtDescripcion.value = this.elemento.descripcion;
    ddlTipo.value = this.elemento.Personal;
    archivoo.value = this.elemento.archivo;

}

//$("#agregar").on("submit", function(e){



function btnAgregar_Click(event) {

 
    var titulo = txtTitulo.value || '';
    var descripcion = txtDescripcion.value || '';
    var tipo = ddlTipo.value || '';
    var archivo = archivoo.value || '';
   
    if (!titulo || !titulo.trim().length) {
        alert('debe ingresar un titulo');
        
        return;

    }
    
    if (!descripcion || !descripcion.trim().length) {
        alert('debe ingresar una descripcion');
        return;
    }

    txtTitulo.value = '';
    txtDescripcion.value = '';
    archivoo.value = '';

    txtTitulo.focus();

    // JSON

    var item = {
        titulo: titulo.trim(),
        descripcion: descripcion.trim(),
        tipo: tipo,
        archivo: archivo.trim(),
        fecha: new Date()
    };

    datos.push(item);
    
    //tablaElementos.innerHTML = '';

    while (tablaElementos.childElementCount > 0) {
        tablaElementos.removeChild(tablaElementos.firstElementChild);
    }
    
    for (var i = 0; i < datos.length; i++) {

        var elemento = datos[i];
        datos2[i] = datos[i];
    console.log(datos2[i]);
       
        var tr = document.createElement('tr');
        var td1 = document.createElement('td');
        var td2 = document.createElement('td');
        var td3 = document.createElement('td');
        var td4 = document.createElement('td');
        var td5 = document.createElement('td');

        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);
        var nombre = elemento.archivo;
        
 
  
      
    
        td1.textContent = elemento.titulo;
        td2.textContent = elemento.descripcion;
        td3.textContent = elemento.tipo;
        td4.textContent = nombre;

        tablaElementos.appendChild(tr);

        var nuevoBoton = document.createElement('button');
        nuevoBoton.type = 'button';
        nuevoBoton.textContent = 'Editar';

        /*  var nuevBoton = document.createElement('input');
        nuevBoton.type = 'file';
        nuevBoton.class ='btn btn-primary';
        nuevBoton.textContent = 'escoger archivo';
         nuevBoton.elemento = elemento;
        td4.appendChild(nuevBoton);
        */
        nuevoBoton.addEventListener('click', btnEditar_Click);
        nuevoBoton.elemento = elemento;
        td5.appendChild(nuevoBoton);
      
       

    }

};

btnAgregar.addEventListener('click', btnAgregar_Click);

</script>
<script type="text/javascript">
 function myFunction(){
    var x = document.getElementById("myFile");
    var txt = "";
    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one or more files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
                txt += "<br><strong>" + (i+1) + ". file</strong><br>";
                var file = x.files[i];
                if ('name' in file) {
                    txt += "name: " + file.name + "<br>";
                }
                if ('size' in file) {
                    txt += "size: " + file.size + " bytes <br>";
                }
            }
        }
    }
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead.
        }
    }
    document.getElementById("demo").innerHTML = txt;
}
          
</script>
<script type="text/javascript">


$('#archivoo').click(function(event){
  var fullPath = document.getElementById('archivo').value;
 
if (fullPath) {
alert('entre');
    var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
    var filename = fullPath.substring(startIndex);
    if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
        filename = filename.substring(1);
    }
    alert(filename);
}
});
  
  $('.btn-addBody').click(function( event ) {
            $('body').append('<div class="divBody">¡Felicidades! Has insertado un nuevo DIV en el BODY</div>')
            });
  $('.btn-addDiv').click(function( event ) {
            $('.contenido').append('<h2>¡Felicidades! Has insertado un texto en el div</h2>')
            });
  $('.btn-changeBody').click(function( event ) {
            $('body').html('<h2>¡Felicidades! Has cambiado el contenido del body</h2>')
            });
  
</script>
<script>
$(document).ready(function(){
  // Add scrollspy to <body>
  $('body').scrollspy({target: ".navbar", offset: 50});

  // Add smooth scrolling on all links inside the navbar
  $("#myNavbar a").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    }  // End if
  });
});
</script>
</body>
</html>