<!DOCTYPE html>

<html>
<?php 
/*include_once("seguridad.php");*/
session_start(); ?>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" type="text/css" href="estilo.css">

<script type="text/javascript" src="js/jquery-1.12.1.js"></script>

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<script type="text/javascript" src="js/bootstrap.js"></script>
	<title>valle</title>
</head>
<header>

        <div id="menu">
            <center>
            <figure id="centro" >
              <img src="aav.jpg">
            </figure>
            </center>
        </div>

<div id="ab" class="navbar navbar-default navbar-fixed" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand" href="#">agencia 
                        </a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav navbar-left">
                                <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Reportes de no conformidad
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#ca" class="ancla">Mis reportes</a></li>
          <li><a href="#es" class="ancla">Reportes pendientes</a></li>
          <li><a href="#in" class="ancla">Instrucciones</a></li> 
          <li><a href="#ag" class="ancla">Agradecimientos</a></li> 
        </ul>
      </li>
                
                <li><a href="#" data-toggle="modal" data-target="#loginModal">hacer reporte</a>
                
                </li>
                <li><a href="#">Seguimiento</a>
                </li>
            </ul>
        </div>
    </div>
</div>
</header>
<body>



 <!-------------------------------- inicio del Form ------------------------------ -->


<div id="loginModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">

      <div class="modal-header">
         <figure><img id="cabee" src="aav.jpg"></figure>
          <h1 class="text-center">"Reporte de no conformidad"</h1>
          </h3>
      </div>
      <div class="modal-body">
      <div id="mensaje" style="border:1px solid #CCC; padding:10px;"></div>
        <!-------------------------------- inicio del Form ------------------------------ -->
          <form class="form-horizontal" role="form" method="POST" accept-charset="utf-8" action="rncfguardar.php">
               <div class="form-group">
                 <label class="col-md-4 control-label">Fecha:
            </label>
                <div class="col-md-6">
                           <label class="col-md-4 control-label" name="fecha" id="fecha">     <script>
var f = new Date();
document.write(f.getFullYear() + "/" + (f.getMonth() +1) + "/" + f.getDate());
</script></label>     
                            </div>
                            </div>
                
          				<div class="form-group">
      <label class="col-md-4 control-label" for="sel1">generar No. no conformidad:</label>
      <div class="col-md-6">
      <select class="form-control" id="sel1" name="sel1">
        <option>AUI</option>
        <option>AUT</option>
        <option>AUP</option>
        <option>SGC</option>
        <option>QCL</option>

      </select>
      </div>
      </div>
                     
                        <div class="form-group">
                        <label class="col-md-4 control-label">Elabora No Conformidad
            </label>
							
							 <div class="col-md-6">
                            <label class="col-md-4 control-label" name="elanocon" id="elanocon"><?php echo $_SESSION['login_user'];?>
            </label>
              </div>
                            </div>
                            <div class="form-group">
                        <label class="col-md-4 control-label">No referencia</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="referencia" id="referencia" >
                            </div>
                            </div>
                             <div class="form-group">
                        <label class="col-md-4 control-label">dep./area identificado</label>
							
							 <div class="col-md-6">
                                <input type="text" class="form-control" name="deparin" id="deparin" >
                            </div>
                            </div>
		 <div class="form-group">
                        <label class="col-md-4 control-label">Responsable de la n.c.</label>
							
							 <div class="col-md-6">
                                <input type="text" class="form-control" name="resnc" id="resnc">
                            </div>
		</div>
		<div class="form-group">
                        <label class="col-md-4 control-label">descripcion de hallazgo</label>
							
							 <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="descdha" name="descdha"></textarea>
                            </div>
                          	 
      
  
		</div>    	
                      

                        
						<div class="modal-footer">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" data-dismiss="modal" id="acceso" name="acceso">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>

                                
                            </div>
                        </div>
                        </div>
            
                    </form>
                    <script type="text/javascript">
/*
   $('document').ready(function()
{ 
    
 
   $("#acceso").click(function(){

      var data = $("#accesoo").serialize();
    
   $.ajax({
    
   type : 'POST',
   url  : 'rncfguardar.php',
   data : data,
   
   success :  function(response)
      {
        
      alert(response);
        /* 
     if(response=="ok"){
         
      $("#btn-login").html('<img src="btn-ajax-loader.gif" /> &nbsp; Signing In ...');
      setTimeout(' window.location.href = "home.php"; ',4000);
     }
     else{
         
      $("#error").fadeIn(1000, function(){      
    $("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; '+response+' !</div>');
           $("#btn-login").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In');
         });
     }

     }*//*
   }
   });
      return false;

   }); 
    
   
});

  
*/
                    </script>
        <!---------------------------------------------------------------------------------->
      </div>
    
  </div>
  </div>
</div>
<section>
  
<article>
  <form class="form-horizontal" role="form">

                     
                <div class="modal-header">
                <center>
                  <article id="tii">
                   <figure id="cabe"><img id="cabee" src="aav.jpg"></figure>
          <h1 class="rell" class="text-center">"Reporte de no conformidad"</h1>
           <?php echo $_SESSION['login_user'];?>
            <h3>Usuario: <?php echo $_SESSION['login_user'] ?> </h3>
                </article>
                </center>
                
        
      </div>
                     
                      <div class="form-group">
                             <div class="col-md-6">
                                <div class="checkbox-inline">
      <label class="col-md-4 control-label"><input type="checkbox"  value="">Mayor</label>
    </div>
    <div class="checkbox-inline">
      <label class="col-md-4 control-label"><input type="checkbox"  value="">Menor</label>
    </div>
    <div class="checkbox-inline">
      <label class="col-md-4 control-label"><input type="checkbox"  value="">Observación</label>
    </div>
    </div>
<div class="form-group">
 <div class="checkbox-inline">
      <label class="col-md-4 control-label"><input type="checkbox"  value="">Real</label>
    </div>
    <div class="checkbox-inline">
      <label class="col-md-4 control-label"><input type="checkbox"  value="">Potencial</label>
    </div>
                            </div>




                      </div>
                      <div class="form-group">                        
        <label class="col-md-4 control-label">seleccion de la norma,manual de calidad o proceso</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="deparin" >
                            </div>
                            </div>
                        <div class="form-group">                        
        <label class="col-md-4 control-label">Elabora No conformidad</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="deparin" >
                            </div>
                            </div>
                             <div class="form-group">                        
        <label class="col-md-4 control-label">dep./area identificado</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="deparin" >
                            </div>
                            </div>
     <div class="form-group">
                        <label class="col-md-4 control-label">Responsable de la n.c.</label>
              
               <div class="col-md-6">
                                <input type="text" class="form-control" name="resnc" >
                            </div>
    </div>
    <div class="form-group">
                        <label class="col-md-4 control-label">descripcion de hallazgo</label>
              
               <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="comment" name="descdha"></textarea>
                            </div>
                             
      
  
    </div>      
       <div class="container">  
         <table  class="table table-hover">
    <thead>
      <tr>
       <th>Actividad</th>
                <th>Descripcion</th>
                <th>Responsable</th>
                <th>Archivo adjunto</th>
                <th>editar</th>
      </tr>
    </thead>
    <tbody id="tabla-elementos">
     
    </tbody>
  </table>            
</div>
                        
            <div class="modal-footer">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" data-dismiss="modal">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>

                                
                            </div>
                        </div>
                        </div>
            
                    </form>

                      <div class="modal-header">
         
          <h1 class="text-center">"Acción Correctiva y/o Preventiva"</h1>
      </div> 
       <!--<button type="button" class="btn btn-warning btn-addBody">Añadir DIV al BODY</button>-->
</article>
<article>
  <form action="/" method="post" class="form-horizontal" role="form">
         <div class="form-group">
                        <label class="col-md-4 control-label">causas raiz de la no confirmidad</label>
              
                <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="comment" name="descdha"></textarea>
                            </div>
                             
                            </div>
<div class="form-group">        
            <label class="col-md-4 control-label" for="titulo">Nombre de actividad:</label>
            <div class="col-md-6"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
 <div class="form-group">
                        <label for="descripcion" class="col-md-4 control-label">Descripcíon de la acción</label>
              
               <div class="col-md-6">
                               <textarea class="form-control" rows="5" id="descripcion" name="descdha"></textarea>
                            </div>
                  </div>  

        
        <div class="form-group">
            <label class="col-md-4 control-label" for="tipo">Personal Responsable:</label>
             <div class="col-md-6">
            <select class="form-control"  id="tipo">
                <option value="1">Tipo 1</option>
                <option value="2">Tipo 2</option>
                <option value="3">Tipo 3</option>
            </select>
            </div>
        </div>
        <div class="form-group">
                        <label for="descripcion" class="col-md-4 control-label">ingresar archivo</label>
              
               <div class="col-md-6">
                               <input type="file" class="form-control"  id="archivo" name="ingar" >
                            </div>
                  </div>  
        
        <div class="modal-footer">
<div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary" data-dismiss="modal" id="archivoo">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>
                                
                                
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="button" class="btn btn-primary" data-dismiss="modal" id="agregar">
                                    <i class="fa fa-btn fa-sign-in"></i>Generar
                                </button>
                                
                                
                            </div>
                        </div>
                        </div>
    </form>
    
    <div class="form-group">        
            <label class="col-md-4 control-label" for="titulo">nombre y firma del responsable de la aplicacion:</label>
            <div class="col-md-6"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
        <div class="form-group">        
            <label class="col-md-4 control-label" for="titulo">Vo.Bo. de la accion gerende y jefe de C y RH:</label>
            <div class="col-md-6"> 
            <input type="text" class="form-control" name="titulo" id="titulo" />
        </div>
        </div>
</article>
 <script type="text/javascript">
  var tablaElementos = document.getElementById('tabla-elementos');

var txtTitulo = document.getElementById('titulo');
var txtDescripcion = document.getElementById('descripcion');
var ddlTipo = document.getElementById('tipo');
var archivoo = document.getElementById('archivo');




var btnAgregar = document.getElementById('agregar');

var datos = [];

function btnEditar_Click(event) {

    txtTitulo.value = this.elemento.titulo;
    txtDescripcion.value = this.elemento.descripcion;
    ddlTipo.value = this.elemento.tipo;
    archivoo.value = this.elemento.archivo;

}



function btnAgregar_Click(event) {

    var titulo = txtTitulo.value || '';
    var descripcion = txtDescripcion.value || '';
    var tipo = ddlTipo.value || '';
    var archivo = archivoo.value || '';
   
    if (!titulo || !titulo.trim().length) {
        alert('debe ingresar un titulo');
        return;
    }
    
    if (!descripcion || !descripcion.trim().length) {
        alert('debe ingresar una descripcion');
        return;
    }

    txtTitulo.value = '';
    txtDescripcion.value = '';
    archivoo.value = '';

    txtTitulo.focus();

    // JSON

    var item = {
        titulo: titulo.trim(),
        descripcion: descripcion.trim(),
        tipo: tipo,
        archivo: archivo.trim(),
        fecha: new Date()
    };

    datos.push(item);
    
    //tablaElementos.innerHTML = '';

    while (tablaElementos.childElementCount > 0) {
        tablaElementos.removeChild(tablaElementos.firstElementChild);
    }

    for (var i = 0; i < datos.length; i++) {

        var elemento = datos[i];

       
        var tr = document.createElement('tr');
        var td1 = document.createElement('td');
        var td2 = document.createElement('td');
        var td3 = document.createElement('td');
        var td4 = document.createElement('td');
        var td5 = document.createElement('td');

        tr.appendChild(td1);
        tr.appendChild(td2);
        tr.appendChild(td3);
        tr.appendChild(td4);
        tr.appendChild(td5);
        var nombre = elemento.archivo;
        
 
  
      
    
        td1.textContent = elemento.titulo;
        td2.textContent = elemento.descripcion;
        td3.textContent = elemento.tipo;
        td4.textContent = nombre;

        tablaElementos.appendChild(tr);

        var nuevoBoton = document.createElement('button');
        nuevoBoton.type = 'button';
        nuevoBoton.textContent = 'Editar';

        /*  var nuevBoton = document.createElement('input');
        nuevBoton.type = 'file';
        nuevBoton.class ='btn btn-primary';
        nuevBoton.textContent = 'escoger archivo';
         nuevBoton.elemento = elemento;
        td4.appendChild(nuevBoton);
        */
        nuevoBoton.addEventListener('click', btnEditar_Click);
        nuevoBoton.elemento = elemento;
        td5.appendChild(nuevoBoton);
      
       

    }

};

btnAgregar.addEventListener('click', btnAgregar_Click);

</script>
<script type="text/javascript">
 function myFunction(){
    var x = document.getElementById("myFile");
    var txt = "";
    if ('files' in x) {
        if (x.files.length == 0) {
            txt = "Select one or more files.";
        } else {
            for (var i = 0; i < x.files.length; i++) {
                txt += "<br><strong>" + (i+1) + ". file</strong><br>";
                var file = x.files[i];
                if ('name' in file) {
                    txt += "name: " + file.name + "<br>";
                }
                if ('size' in file) {
                    txt += "size: " + file.size + " bytes <br>";
                }
            }
        }
    }
    else {
        if (x.value == "") {
            txt += "Select one or more files.";
        } else {
            txt += "The files property is not supported by your browser!";
            txt  += "<br>The path of the selected file: " + x.value; // If the browser does not support the files property, it will return the path of the selected file instead.
        }
    }
    document.getElementById("demo").innerHTML = txt;
}
          
</script>
<script type="text/javascript">


$('#archivoo').click(function(event){
  var fullPath = document.getElementById('archivo').value;
 
if (fullPath) {
alert('entre');
    var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
    var filename = fullPath.substring(startIndex);
    if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
        filename = filename.substring(1);
    }
    alert(filename);
}
});
  
  $('.btn-addBody').click(function( event ) {
            $('body').append('<div class="divBody">¡Felicidades! Has insertado un nuevo DIV en el BODY</div>')
            });
  $('.btn-addDiv').click(function( event ) {
            $('.contenido').append('<h2>¡Felicidades! Has insertado un texto en el div</h2>')
            });
  $('.btn-changeBody').click(function( event ) {
            $('body').html('<h2>¡Felicidades! Has cambiado el contenido del body</h2>')
            });
  
</script>
<script type="text/javascript">
  

</script>
</section>
</body>
</html>